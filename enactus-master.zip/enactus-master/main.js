function originalmode(){


    document.body.style.backgroundColor="white";
    document.body.style.transition="all 1s ease";



}

function dark(){

document.body.style.backgroundColor="black";
 document.body.style.transition="all 1s ease";

}
